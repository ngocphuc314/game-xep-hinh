package com.rose.tetris;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

// Trong file MainActivity.java hoặc tương tự
public class StartActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Ánh xạ TextView và Button từ layout XML
        TextView textViewHello = findViewById(R.id.textViewHello);
        Button buttonStart = findViewById(R.id.buttonStart);

        // Bắt sự kiện khi Button được click
        buttonStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Tạo Intent để chuyển từ MainActivity này sang MainActivity2
                Intent intent = new Intent( StartActivity.this, MainActivity.class);

                // Khởi chạy MainActivity2 bằng Intent
                startActivity(intent);
            }
        });
    }
}
